import React from 'react'

function Home() {
    return (
        <div className=' w-100'>
            <div className='w100'>
                <img className='w-100' src='./img/th.jpg' />
            </div>
            <h1 className='mt-5 mb-5 text-center'>Welcome To Online Courses</h1>
        </div>
    )
}

export default Home