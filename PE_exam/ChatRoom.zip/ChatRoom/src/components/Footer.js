import React from 'react'

function Footer() {
    return (
        <div className='container-fluid p-5 d-flex justify-content-center align-items-center' style={{ backgroundColor: 'orange' }}>
            <p>@2024-Created by FPTU</p>
        </div>
    )
}

export default Footer