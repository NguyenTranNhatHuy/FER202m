import React from 'react'
import Carousel from './Carousel'

function Home() {
    return (
        <div className=''>
            <div className='p-5 mt-5'>
                <h1 className='text-danger text-center'>Welcome to Simple Chat Room</h1>

            </div>
        </div>
    )
}

export default Home