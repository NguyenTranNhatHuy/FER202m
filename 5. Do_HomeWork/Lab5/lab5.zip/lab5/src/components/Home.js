import React from 'react'
import Carousel from './Carousel'
import { Link } from 'react-router-dom'

function Home() {
    return (
        <>
            <Carousel />
        </>
    )
}

export default Home