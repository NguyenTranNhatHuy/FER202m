import React from 'react'

export default function About() {
    return (
        <div >
            <h1 className='text-danger'>This is About Page</h1>
            <h1>My name is Nguyen Tran Nhat Huy</h1>
        </div>
    )
}
