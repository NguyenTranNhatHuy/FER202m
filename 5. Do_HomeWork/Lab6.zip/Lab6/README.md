# Lab 6.2
> Copy from [GitHub](https://github.com/sahoochinmay/quiz-app)

## Documents
- Document: [Click here!!!](Lab6_About_Redux_Redux_Thunk_Redux_Toolkit.docx.pdf)

## Build
### Install dependencies:
```bash
npm install
```
### Run:
```bash
npm start
```