$(function () {
    $("#login").click(function () {
        $("#loginModal").modal('show');
    });
});

$(function () {
    $("#Reverse").click(function () {
        $("#ReverseModal").modal('show');
    });
});

